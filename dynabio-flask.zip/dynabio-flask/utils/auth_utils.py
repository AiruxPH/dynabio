import random
import string
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import current_app

def generate_verification_code():
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(6))

def send_verification_email(email, code, email_type='signup'):
    subject = 'Verify your Dynabio Account' if email_type == 'signup' else 'Dynabio Password Reset Verification'
    message_html = f"""
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;'>
        <h2 style='color: #333;'>Dynabio Verification</h2>
        <p>Your verification code is:</p>
        <h1 style='color: #007BFF; letter-spacing: 4px; font-family: "Courier New", Courier, monospace; background: #f8f9fa; padding: 10px; text-align: center; border-radius: 5px;'>{code}</h1>
        <p>Please enter this code on the website to continue.</p>
        <p style='color: #777; font-size: 12px;'>If you didn't request this, please ignore this email.</p>
    </div>
    """
    
    print(f"\n=============================================")
    print(f"DEVELOPER MODE - {email_type.upper()} VERIFICATION CODE")
    print(f"Email: {email}")
    print(f"Code: {code}")
    print(f"=============================================\n")
    
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = current_app.config['MAIL_DEFAULT_SENDER']
        msg['To'] = email
        msg['Reply-To'] = 'noreply@dynabio.com'

        part = MIMEText(message_html, 'html')
        msg.attach(part)

        server = smtplib.SMTP(current_app.config['MAIL_SERVER'], current_app.config['MAIL_PORT'])
        server.starttls()
        server.login(current_app.config['MAIL_USERNAME'], current_app.config['MAIL_PASSWORD'])
        server.sendmail(msg['From'], email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email via SMTP: {e}")
        return False

def perform_account_expiration_checks(db, user):
    if user.get('is_verified') == 1 or not user.get('date_registered'):
        return False
        
    diff = datetime.now() - user['date_registered']
    if diff.days >= 7:
        with db.cursor() as cursor:
            cursor.execute("DELETE FROM users WHERE user_id = %s", (user['user_id'],))
        return True
    return False

def is_code_expired(date_registered):
    if not date_registered:
        return False
    diff = datetime.now() - date_registered
    return diff.days >= 1
