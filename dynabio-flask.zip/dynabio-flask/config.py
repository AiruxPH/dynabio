import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'super-secret-dynabio-key'
    
    DB_HOST = os.environ.get('DB_HOST') or 'localhost'
    DB_NAME = os.environ.get('DB_NAME') or 'dynabio'
    DB_USER = os.environ.get('DB_USER') or 'root'
    DB_PASS = os.environ.get('DB_PASS') or ''
    DB_CHARSET = 'utf8mb4'
    
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'randythegreat000@gmail.com'
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'uykbcvybxnollhyw'
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_USERNAME') or 'randythegreat000@gmail.com'
