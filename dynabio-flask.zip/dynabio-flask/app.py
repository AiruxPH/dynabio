import sys
import subprocess

# --- DYNABIO ENGINE AUTO-INSTALLER ---
try:
    import flask
    import pymysql
    import bcrypt
    import dotenv
    import requests
except ImportError:
    print("\n=========================================================")
    print(" Dynabio Engine: Missing required Python libraries!")
    print(" Automatically installing dependencies via pip...")
    print("=========================================================\n")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "pymysql", "bcrypt", "python-dotenv", "requests"])
    print("\n[+] Installation complete! Restarting application...\n")
    sys.exit(subprocess.call([sys.executable] + sys.argv))
# -------------------------------------

from flask import Flask, render_template
from db import init_app

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    init_app(app)

    from routes.auth import auth_bp
    from routes.main import main_bp
    from routes.user import user_bp
    from routes.public import public_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(public_bp)

    @app.route('/favicon.ico')
    def favicon():
        return '', 204

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
