# Initialize blueprints
