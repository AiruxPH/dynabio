from flask import Blueprint, render_template, request, abort
from db import get_db
import json
import urllib.request
import urllib.parse
from datetime import datetime

public_bp = Blueprint('public', __name__)

@public_bp.route('/<username>')
def profile(username):
    if username in ['favicon.ico', 'static', 'api', 'auth', 'user']:
        abort(404)
        
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("""
            SELECT u.user_id, u.photo, b.*, b.user_id AS has_biodata 
            FROM users u
            LEFT JOIN biodata b ON u.user_id = b.user_id
            WHERE u.username = %s
        """, (username,))
        profile_data = cursor.fetchone()
        
    if not profile_data:
        return render_template('public.html', error_state=True, error_message="Profile not found.", current_theme="default-glass", full_name="")
        
    user_id = profile_data['user_id']
    is_new_user = not profile_data.get('has_biodata')
    
    theme = profile_data.get('theme') or 'default-glass'
    full_name = profile_data.get('full_name') or username
    tagline = profile_data.get('tagline') or ''
    about_me = profile_data.get('about_me') or ''
    about_me = about_me.replace('\n', '<br>')
    location = profile_data.get('location') or ''
    
    photo = profile_data.get('photo') or 'user-placeholder.png'
    if photo != 'user-placeholder.png' and photo.startswith('../'):
        photo = photo[3:]
        
    skills = []
    if profile_data.get('skills'):
        try:
            skills = json.loads(profile_data['skills'])
        except Exception: pass
        
    social_links = {}
    if profile_data.get('social_links'):
        try:
            social_links = json.loads(profile_data['social_links'])
        except Exception: pass
        
    platform_icons = {
        'twitter': 'fa-x-twitter',
        'github': 'fa-github',
        'linkedin': 'fa-linkedin-in',
        'instagram': 'fa-instagram',
        'youtube': 'fa-youtube',
        'facebook': 'fa-facebook-f',
        'website': 'fa-globe'
    }
    
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM milestones WHERE user_id = %s ORDER BY milestone_date DESC", (user_id,))
        milestones = cursor.fetchall()
        
    for m in milestones:
        if m.get('milestone_date'):
            m['formatted_date'] = m.get('milestone_date').strftime('%B %d, %Y').replace(' 0', ' ')
        if m.get('description'):
            m['description'] = m.get('description').replace('\n', '<br>')
            
    age = None
    formatted_dob = None
    if profile_data.get('date_of_birth'):
        if isinstance(profile_data['date_of_birth'], str):
            dob = datetime.strptime(profile_data['date_of_birth'], '%Y-%m-%d').date()
        else:
            dob = profile_data['date_of_birth']
        now = datetime.now().date()
        age = now.year - dob.year - ((now.month, now.day) < (dob.month, dob.day))
        formatted_dob = dob.strftime('%B %d, %Y').replace(' 0', ' ')
        
    github_data = None
    github_username = profile_data.get('github_username')
    
    if github_username:
        with db.cursor() as cursor:
            cursor.execute("SELECT api_response, updated_at FROM github_cache WHERE user_id = %s", (user_id,))
            cache = cursor.fetchone()
            
            use_cache = False
            if cache and cache.get('updated_at'):
                elapsed = (datetime.now() - cache['updated_at']).total_seconds()
                if elapsed < 4 * 3600:
                    use_cache = True
                    
            if use_cache:
                try:
                    github_data = json.loads(cache['api_response'])
                except:
                    use_cache = False
                    
            if not use_cache:
                try:
                    url = f"https://api.github.com/users/{urllib.parse.quote(github_username)}/repos?sort=updated&per_page=3"
                    req = urllib.request.Request(url, headers={'User-Agent': 'DynaBio-Portfolio-Engine'})
                    with urllib.request.urlopen(req, timeout=5) as response:
                        api_response = response.read().decode('utf-8')
                        github_data = json.loads(api_response)
                        
                        cursor.execute("""
                            INSERT INTO github_cache (user_id, api_response) 
                            VALUES (%s, %s) 
                            ON DUPLICATE KEY UPDATE api_response = VALUES(api_response)
                        """, (user_id, api_response))
                except Exception:
                    if cache:
                        try:
                            github_data = json.loads(cache['api_response'])
                        except: pass
                        
    return render_template('public.html',
        error_state=False,
        is_new_user=is_new_user,
        current_theme=theme,
        full_name=full_name,
        tagline=tagline,
        about_me=about_me,
        location=location,
        photo=photo,
        skills=skills,
        social_links=social_links,
        platform_icons=platform_icons,
        milestones=milestones,
        github_data=github_data,
        github_username=github_username,
        profile=profile_data,
        age=age,
        formatted_dob=formatted_dob
    )
