from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify
from db import get_db

user_bp = Blueprint('user', __name__, url_prefix='/user')

@user_bp.route('/profile', methods=['GET'])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
        
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT user_id, email, username, role, photo FROM users WHERE user_id = %s", (session['user_id'],))
        user = cursor.fetchone()
        
    if not user:
        session.clear()
        return redirect(url_for('auth.login'))
        
    return render_template('user/profile.html', user=user)

@user_bp.route('/themes', methods=['GET'])
def themes():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
        
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT theme FROM biodata WHERE user_id = %s", (session['user_id'],))
        biodata = cursor.fetchone()
        
    current_theme = biodata['theme'] if biodata and biodata.get('theme') else 'default-glass'
    return render_template('themes.html', current_theme=current_theme)

import json

@user_bp.route('/editor', methods=['GET'])
def editor():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
        
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE user_id = %s", (session['user_id'],))
        user = cursor.fetchone()
        
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM biodata WHERE user_id = %s", (session['user_id'],))
        biodata = cursor.fetchone() or {}
        
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM milestones WHERE user_id = %s ORDER BY milestone_date DESC", (session['user_id'],))
        milestones = cursor.fetchall()
        
    skills = []
    if biodata.get('skills'):
        try:
            skills = json.loads(biodata['skills'])
        except Exception:
            pass
            
    social_links = {}
    if biodata.get('social_links'):
        try:
            social_links = json.loads(biodata['social_links'])
        except Exception:
            pass
            
    family_background = {}
    if biodata.get('family_background'):
        try:
            family_background = json.loads(biodata['family_background'])
        except Exception:
            pass
            
    for m in milestones:
        if m.get('milestone_date'):
            m['formatted_date'] = m.get('milestone_date').strftime('%B %d, %Y').replace(' 0', ' ')
            
    return render_template(
        'user/editor.html', 
        user=user, 
        biodata=biodata, 
        milestones=milestones, 
        skills=skills, 
        social_links=social_links, 
        family_background=family_background
    )

@user_bp.route('/action_update_biodata', methods=['POST'])
def action_update_biodata():
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Unauthorized."})
        
    data = request.json or {}
    user_id = session['user_id']
    
    full_name = data.get('full_name', '').strip()
    tagline = data.get('tagline', '').strip()
    about_me = data.get('about_me', '').strip()
    location = data.get('location', '').strip()
    
    skills = data.get('skills', []) if isinstance(data.get('skills'), list) else []
    if len(skills) > 15:
        skills = skills[:15]
        
    social_links_in = data.get('social_links', {}) if isinstance(data.get('social_links'), dict) else {}
    sanitized_socials = {}
    allowed_platforms = ['twitter', 'github', 'linkedin', 'instagram', 'youtube', 'facebook', 'website']
    
    url_pattern = re.compile(
        r'^(?:http|ftp)s?://' 
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|' 
        r'localhost|' 
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' 
        r'(?::\d+)?' 
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        
    for platform, url in social_links_in.items():
        if platform in allowed_platforms and re.match(url_pattern, url):
            sanitized_socials[platform] = url.strip()
            
    position_desired = data.get('position_desired', '').strip()
    nickname = data.get('nickname', '').strip()
    present_address = data.get('present_address', '').strip()
    provincial_address = data.get('provincial_address', '').strip()
    place_of_birth = data.get('place_of_birth', '').strip()
    citizenship = data.get('citizenship', '').strip()
    gender = data.get('gender', '').strip()
    date_of_birth = data.get('date_of_birth', '').strip() or None
    civil_status = data.get('civil_status', '').strip()
    religion = data.get('religion', '').strip()
    height = data.get('height', '').strip()
    weight = data.get('weight', '').strip()
    github_username = data.get('github_username', '').strip()
    
    family_background_in = data.get('family_background', {}) if isinstance(data.get('family_background'), dict) else {}
    family_background = {
        'spouse': family_background_in.get('spouse', ''),
        'children': family_background_in.get('children', ''),
        'parents': family_background_in.get('parents', '')
    }
    
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT user_id FROM biodata WHERE user_id = %s", (user_id,))
            exists = cursor.fetchone()
            
            if exists:
                sql = """UPDATE biodata SET 
                    full_name = %s, tagline = %s, about_me = %s, location = %s, 
                    position_desired = %s, nickname = %s, present_address = %s, provincial_address = %s, 
                    place_of_birth = %s, citizenship = %s, gender = %s, date_of_birth = %s, civil_status = %s, religion = %s, 
                    height = %s, weight = %s, family_background = %s, github_username = %s, 
                    social_links = %s, skills = %s 
                    WHERE user_id = %s"""
                cursor.execute(sql, (
                    full_name, tagline, about_me, location, position_desired, nickname, present_address, provincial_address,
                    place_of_birth, citizenship, gender, date_of_birth, civil_status, religion, height, weight,
                    json.dumps(family_background), github_username, json.dumps(sanitized_socials), json.dumps(skills), user_id
                ))
            else:
                sql = """INSERT INTO biodata 
                    (user_id, theme, full_name, tagline, about_me, location, position_desired, nickname, present_address, provincial_address, place_of_birth, citizenship, gender, date_of_birth, civil_status, religion, height, weight, family_background, github_username, social_links, skills) 
                    VALUES (%s, 'default-glass', %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                cursor.execute(sql, (
                    user_id, full_name, tagline, about_me, location, position_desired, nickname, present_address, provincial_address,
                    place_of_birth, citizenship, gender, date_of_birth, civil_status, religion, height, weight,
                    json.dumps(family_background), github_username, json.dumps(sanitized_socials), json.dumps(skills)
                ))
                
        return jsonify({"success": True, "message": "Biodata successfully saved."})
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500

@user_bp.route('/action_manage_milestones', methods=['POST'])
def action_manage_milestones():
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Unauthorized."})
        
    data = request.json or {}
    action = data.get('action')
    if not action:
        return jsonify({"success": False, "message": "No action specified."})
        
    user_id = session['user_id']
    target_action = str(action)
    db = get_db()
    
    try:
        if target_action == 'add':
            date_val = data.get('date', '').strip()
            title = data.get('title', '').strip()
            desc = data.get('desc', '').strip()
            icon = data.get('icon', '').strip()
            
            if not date_val or not title:
                return jsonify({"success": False, "message": "Date and Title are required."})
                
            with db.cursor() as cursor:
                cursor.execute("INSERT INTO milestones (user_id, milestone_date, title, description, icon) VALUES (%s, %s, %s, %s, %s)", (user_id, date_val, title, desc, icon))
                
            return jsonify({"success": True, "message": "Milestone appended to journey."})
            
        elif target_action == 'delete':
            ms_id = int(data.get('id', 0))
            with db.cursor() as cursor:
                cursor.execute("DELETE FROM milestones WHERE milestone_id = %s AND user_id = %s", (ms_id, user_id))
                affected = cursor.rowcount
            if affected > 0:
                return jsonify({"success": True, "message": "Milestone deleted."})
            else:
                return jsonify({"success": False, "message": "Milestone not found or permission denied."})
        else:
            return jsonify({"success": False, "message": "Unknown action."})
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500

@user_bp.route('/action_change_theme', methods=['POST'])
def action_change_theme():
    if 'user_id' not in session:
        return jsonify({"success": False, "message": "Unauthorized."})
        
    data = request.json or {}
    new_theme = data.get('theme', '').strip()
    user_id = session['user_id']
    
    allowed_themes = [
        'default-glass', 'neon-cyberpunk', 'midnight-blue', 
        'minimal-light', 'solarized-amber', 'emerald-matrix', 
        'rose-quartz', 'deep-space'
    ]
    
    if new_theme not in allowed_themes:
        return jsonify({"success": False, "message": "Invalid theme selected."})
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT user_id FROM biodata WHERE user_id = %s", (user_id,))
            if cursor.fetchone():
                cursor.execute("UPDATE biodata SET theme = %s WHERE user_id = %s", (new_theme, user_id))
            else:
                cursor.execute(
                    "INSERT INTO biodata (user_id, theme, full_name, tagline, about_me, location, social_links, skills) VALUES (%s, %s, '', '', '', '', '{}', '[]')",
                    (user_id, new_theme)
                )
        return jsonify({"success": True, "message": "Theme applied successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500
