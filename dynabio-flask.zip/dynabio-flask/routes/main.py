from flask import Blueprint, render_template, session, redirect, url_for, request
from db import get_db
import json
import os
import re
import urllib.request
import urllib.parse
from datetime import datetime

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
        
    db = get_db()
    
    with db.cursor() as cursor:
        cursor.execute("SELECT email, role, photo, username FROM users WHERE user_id = %s", (session['user_id'],))
        logged_in_user = cursor.fetchone()
        
    if not logged_in_user:
        session.clear()
        return redirect(url_for('auth.login'))
        
    site_owner_email = os.environ.get('SITE_OWNER_EMAIL', 'randythegreat000@gmail.com')
    
    with db.cursor() as cursor:
        cursor.execute("""
            SELECT u.user_id, u.photo, u.username, b.* 
            FROM users u
            LEFT JOIN biodata b ON u.user_id = b.user_id
            WHERE u.email = %s
        """, (site_owner_email,))
        profile = cursor.fetchone()
        
    if not profile:
        return f"Site Owner with email '{site_owner_email}' not found. Please ensure the user exists before viewing the dashboard."
        
    owner_id = int(profile['user_id'])
    is_owner_empty = not profile.get('theme')
    
    current_theme = profile.get('theme') or 'default-glass'
    full_name = profile.get('full_name') or profile.get('username')
    tagline = profile.get('tagline') or ''
    about_me = profile.get('about_me') or ''
    location = profile.get('location') or ''
    
    photo = profile.get('photo') or 'user-placeholder.png'
    if photo != 'user-placeholder.png' and photo.startswith('../'):
        photo = photo[3:]
        
    skills = []
    if profile.get('skills'):
        try:
            skills = json.loads(profile['skills'])
        except Exception:
            pass
            
    social_links = {}
    if profile.get('social_links'):
        try:
            social_links = json.loads(profile['social_links'])
        except Exception:
            pass
            
    platform_icons = {
        'twitter': 'fa-x-twitter',
        'github': 'fa-github',
        'linkedin': 'fa-linkedin-in',
        'instagram': 'fa-instagram',
        'youtube': 'fa-youtube',
        'facebook': 'fa-facebook-f',
        'website': 'fa-globe'
    }
    
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM milestones WHERE user_id = %s ORDER BY milestone_date DESC", (owner_id,))
        milestones = cursor.fetchall()
        
    for m in milestones:
        if m.get('milestone_date'):
            m['formatted_date'] = m.get('milestone_date').strftime('%B %d, %Y')
            
    # Age calculation
    age = None
    formatted_dob = None
    if profile.get('date_of_birth'):
        if isinstance(profile['date_of_birth'], str):
            dob = datetime.strptime(profile['date_of_birth'], '%Y-%m-%d').date()
        else:
            dob = profile['date_of_birth']
        now = datetime.now().date()
        age = now.year - dob.year - ((now.month, now.day) < (dob.month, dob.day))
        formatted_dob = dob.strftime('%B %d, %Y')
        
    # JSON family background
    family_background = {}
    if profile.get('family_background'):
        try:
            family_background = json.loads(profile['family_background'])
        except Exception:
            pass
            
    github_username = profile.get('github_username')
    github_data = None
    
    if github_username:
        with db.cursor() as cursor:
            cursor.execute("SELECT api_response, updated_at FROM github_cache WHERE user_id = %s", (owner_id,))
            cache = cursor.fetchone()
            
            use_cache = False
            if cache and cache.get('updated_at'):
                elapsed = (datetime.now() - cache['updated_at']).total_seconds()
                if elapsed < 4 * 3600:
                    use_cache = True
                    
            if use_cache:
                try:
                    github_data = json.loads(cache['api_response'])
                except:
                    use_cache = False
                    
            if not use_cache:
                try:
                    url = f"https://api.github.com/users/{urllib.parse.quote(github_username)}/repos?sort=updated&per_page=3"
                    req = urllib.request.Request(url, headers={'User-Agent': 'DynaBio-Portfolio-Engine'})
                    with urllib.request.urlopen(req, timeout=5) as response:
                        api_response = response.read().decode('utf-8')
                        github_data = json.loads(api_response)
                        
                        cursor.execute("""
                            INSERT INTO github_cache (user_id, api_response) 
                            VALUES (%s, %s) 
                            ON DUPLICATE KEY UPDATE api_response = VALUES(api_response)
                        """, (owner_id, api_response))
                except Exception:
                    if cache:
                        try:
                            github_data = json.loads(cache['api_response'])
                        except: pass
    
    is_site_owner = (logged_in_user['email'].lower() == site_owner_email.lower())
    
    # Text replacing newlines to <br> for about_me equivalent to nl2br
    about_me = about_me.replace('\n', '<br>')
    for m in milestones:
        if m.get('description'):
            m['description'] = m['description'].replace('\n', '<br>')
            
    return render_template(
        'dashboard.html',
        logged_in_user=logged_in_user,
        profile=profile,
        is_owner_empty=is_owner_empty,
        current_theme=current_theme,
        full_name=full_name,
        tagline=tagline,
        about_me=about_me,
        location=location,
        photo=photo,
        skills=skills,
        social_links=social_links,
        platform_icons=platform_icons,
        milestones=milestones,
        family_background=family_background,
        github_username=github_username,
        github_data=github_data,
        is_site_owner=is_site_owner,
        formatted_dob=formatted_dob,
        age=age
    )

@main_bp.route('/about')
def about():
    return render_template('about.html')
