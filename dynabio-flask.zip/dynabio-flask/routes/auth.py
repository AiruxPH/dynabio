import bcrypt
from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from db import get_db
from utils.auth_utils import perform_account_expiration_checks, is_code_expired, generate_verification_code, send_verification_email

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET'])
def login():
    if 'user_id' in session:
        return redirect(url_for('main.index'))
    return render_template('auth/login.html')

@auth_bp.route('/action_login', methods=['POST'])
def action_login():
    data = request.json or {}
    identifier = data.get('email', '')
    password = data.get('password', '')
    remember = data.get('remember', False)
    
    if not identifier or not password:
        return jsonify({"success": False, "message": "Email/Username and password are required."}), 400
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s OR username = %s LIMIT 1", (identifier, identifier))
            user = cursor.fetchone()
            
        if not user:
            return jsonify({"success": False, "message": "Invalid email/username or password."})
            
        if user['is_verified'] == 0:
            if perform_account_expiration_checks(db, user):
                return jsonify({
                    "success": False, 
                    "message": "Your unverified account expired after 7 days and was deleted. Please sign up again.",
                    "redirect": url_for('auth.signup')
                })
                
            if is_code_expired(user['date_registered']):
                code = generate_verification_code()
                with db.cursor() as cursor:
                    cursor.execute("UPDATE users SET verification_code = %s, date_registered = NOW() WHERE user_id = %s", (code, user['user_id']))
                send_verification_email(user['email'], code, 'signup')
                return jsonify({
                    "success": False,
                    "message": "Verification expired safely. A new code was sent to your email. Redirecting...",
                    "redirect": url_for('auth.verify', email=user['email'])
                })
                
            return jsonify({
                "success": False,
                "message": "Your account is not verified. Please check your email. Redirecting...",
                "redirect": url_for('auth.verify', email=user['email'])
            })
            
        hashed_pw = user['password']
        if hashed_pw.startswith('$2y$'):
            hashed_pw = '$2b$' + hashed_pw[4:]
            
        if not bcrypt.checkpw(password.encode('utf-8'), hashed_pw.encode('utf-8')):
            return jsonify({"success": False, "message": "Invalid email/username or password."})
            
        session['user_id'] = user['user_id']
        session['email'] = user['email']
        session['role'] = user['role']
        session.permanent = bool(remember)
        
        return jsonify({
            "success": True,
            "message": "Login successful!",
            "redirect": url_for('main.index'),
            "user": {
                "user_id": user['user_id'],
                "username": user['username'],
                "photo": user['photo']
            }
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500

import re
import dns.resolver

@auth_bp.route('/action_signup', methods=['POST'])
def action_signup():
    data = request.json or {}
    email = data.get('email', '')
    
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return jsonify({"success": False, "message": "Invalid email address."})
        
    domain = email.split('@')[-1]
    try:
        dns.resolver.resolve(domain, 'MX')
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.Timeout, Exception):
        return jsonify({"success": False, "message": "Invalid email domain. Cannot receive mail."})
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            
        is_new_account = True
        
        if user:
            if user['is_verified'] == 1:
                return jsonify({"success": False, "message": "An account with this email already exists and is verified.", "redirect": url_for('auth.login')})
                
            deleted = perform_account_expiration_checks(db, user)
            if not deleted:
                is_new_account = False
                
        code = generate_verification_code()
        
        if is_new_account:
            with db.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO users (email, password, verification_code, date_registered, role, is_verified) VALUES (%s, '', %s, NOW(), 'client', 0)", 
                    (email, code)
                )
        else:
            with db.cursor() as cursor:
                cursor.execute(
                    "UPDATE users SET verification_code = %s, date_registered = NOW() WHERE user_id = %s", 
                    (code, user['user_id'])
                )
                
        if send_verification_email(email, code, 'signup'):
            return jsonify({
                "success": True, 
                "message": "Verification code sent! Please check your email.", 
                "redirect": url_for('auth.verify', email=email)
            })
        else:
            return jsonify({"success": False, "message": "Failed to send the verification email. Please try again later."})
            
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500

@auth_bp.route('/signup', methods=['GET'])
def signup():
    return render_template('auth/signup.html')


@auth_bp.route('/verify', methods=['GET'])
def verify():
    email = request.args.get('email', '')
    if not email:
        return redirect(url_for('auth.signup'))
    return render_template('auth/verify.html', email=email)

@auth_bp.route('/action_verify', methods=['POST'])
def action_verify():
    data = request.json or {}
    email = data.get('email', '')
    code = data.get('code', '')
    
    if not email or not code or len(code) != 6:
        return jsonify({"success": False, "message": "Invalid verification code format."})
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s AND verification_code = %s", (email, code))
            user = cursor.fetchone()
            
        if not user:
            return jsonify({"success": False, "message": "Incorrect verification code. Please try again."})
            
        if user['is_verified'] == 0 and is_code_expired(user['date_registered']):
            return jsonify({"success": False, "message": "This verification code has expired (older than 24 hours). Please sign up again.", "redirect": url_for('auth.signup')})
            
        session['verified_email'] = user['email']
        
        return jsonify({"success": True, "message": "Code verified successfully! Redirecting...", "redirect": url_for('auth.set_password')})
        
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500


@auth_bp.route('/action_sync_accounts', methods=['POST'])
def action_sync_accounts():
    data = request.json or {}
    accounts = data.get('accounts', [])
    
    if not isinstance(accounts, list) or not accounts:
        return jsonify({"success": True, "synced_accounts": []})
        
    synced_accounts = []
    db = get_db()
    try:
        with db.cursor() as cursor:
            for acc in accounts:
                if 'username' not in acc:
                    continue
                user = None
                if 'user_id' in acc:
                    cursor.execute("SELECT user_id, username, photo FROM users WHERE user_id = %s AND is_archived = 0 AND is_verified = 1", (acc['user_id'],))
                    user = cursor.fetchone()
                else:
                    cursor.execute("SELECT user_id, username, photo FROM users WHERE username = %s AND is_archived = 0 AND is_verified = 1", (acc['username'],))
                    user = cursor.fetchone()
                    
                if user:
                    synced_accounts.append({
                        "user_id": user['user_id'],
                        "username": user['username'],
                        "avatar_url": user.get('photo') or 'images/default.png',
                        "last_login": acc.get('last_login', 0)
                    })
    except Exception as e:
        pass
        
    return jsonify({"success": True, "synced_accounts": synced_accounts})

@auth_bp.route('/action_forgot', methods=['POST'])
def action_forgot():
    data = request.json or {}
    email = data.get('email', '')
    
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return jsonify({"success": False, "message": "Invalid email address."})
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            
        if not user:
            return jsonify({"success": False, "message": "This email is not found or does not have an account affiliated with it."})
            
        if user['is_verified'] == 0:
            return jsonify({"success": False, "message": "This account is not verified. Please log in to trigger a new verification code.", "redirect": url_for('auth.login')})
            
        code = generate_verification_code()
        
        with db.cursor() as cursor:
            cursor.execute("UPDATE users SET verification_code = %s WHERE user_id = %s", (code, user['user_id']))
            
        if send_verification_email(email, code, 'forgot_password'):
            return jsonify({"success": True, "message": "A recovery code was sent! Please check your email.", "redirect": url_for('auth.verify', email=email)})
        else:
            return jsonify({"success": False, "message": "Failed to send the recovery email. Please try again later."})
            
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500

@auth_bp.route('/forgot_password', methods=['GET'])
def forgot_password():
    is_logged_in = 'user_id' in session
    return render_template('auth/forgot_password.html', isLoggedIn=is_logged_in)


@auth_bp.route('/logout', methods=['GET'])
def logout():
    session.clear()
    return redirect(url_for('auth.login', logout='success'))


@auth_bp.route('/set_password', methods=['GET'])
def set_password():
    if 'verified_email' not in session:
        return redirect(url_for('auth.signup'))
    return render_template('auth/set_password.html')

@auth_bp.route('/action_set_password', methods=['POST'])
def action_set_password():
    if 'verified_email' not in session:
        return jsonify({"success": False, "message": "Session expired. Please verify your email again.", "redirect": url_for('auth.login')})
        
    email = session['verified_email']
    data = request.json or {}
    password = data.get('password', '')
    
    if len(password) < 8:
        return jsonify({"success": False, "message": "Password must be at least 8 characters long."})
        
    if not (re.search(r'[A-Z]', password) and re.search(r'[a-z]', password) and re.search(r'[0-9]', password) and re.search(r'[^A-Za-z0-9]', password)):
        return jsonify({"success": False, "message": "Password does not meet the requirements."})
        
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT user_id, password FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            
        if not user:
            return jsonify({"success": False, "message": "User not found.", "redirect": url_for('auth.login')})
            
        is_signup_flow = not user['password']
        
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        with db.cursor() as cursor:
            cursor.execute("UPDATE users SET password = %s, is_verified = 1 WHERE email = %s", (hashed_password, email))
            
        session.pop('verified_email', None)
        
        if is_signup_flow:
            session['setup_user_id'] = user['user_id']
            return jsonify({"success": True, "message": "Account registered successfully! Redirecting to setup...", "redirect": url_for('auth.set_username')})
        else:
            session['user_id'] = user['user_id']
            session['email'] = email
            with db.cursor() as cursor:
                cursor.execute("SELECT role FROM users WHERE user_id = %s", (user['user_id'],))
                role_row = cursor.fetchone()
                session['role'] = role_row['role'] if role_row else 'client'
                
            return jsonify({"success": True, "message": "Password updated successfully! Logging you in...", "redirect": url_for('main.index')})
            
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500
@auth_bp.route('/action_set_username', methods=['POST'])
def action_set_username():
    if 'setup_user_id' not in session and 'user_id' not in session:
        return jsonify({"success": False, "message": "Session expired. Please login.", "redirect": url_for('auth.login')})
        
    is_setup_flow = 'setup_user_id' in session
    user_id = session.get('setup_user_id') if is_setup_flow else session.get('user_id')
    
    data = request.json or {}
    skip = data.get('skip', False)
    username = data.get('username', '').strip()
    
    db = get_db()
    try:
        if skip:
            padded_id = str(user_id).zfill(6)
            generated_username = f"user_{padded_id}"
            
            with db.cursor() as cursor:
                cursor.execute("UPDATE users SET username = %s WHERE user_id = %s", (generated_username, user_id))
                
            if is_setup_flow:
                session.pop('setup_user_id', None)
                return jsonify({"success": True, "message": "Username auto-generated! Redirecting to login...", "redirect": url_for('auth.login')})
            else:
                return jsonify({"success": True, "message": "Username auto-generated!"})
        else:
            if not username:
                return jsonify({"success": False, "message": "Please enter a username or click skip."})
                
            if username != username.lower():
                return jsonify({"success": False, "message": "Username must be strictly lowercase."})
                
            if not re.match(r'^[a-zA-Z0-9](_(?!_)|[a-zA-Z0-9]){2,18}[a-zA-Z0-9]$', username):
                return jsonify({"success": False, "message": "Username must be 4-20 characters, alphanumeric or single underscores, and cannot start/end with an underscore."})
                
            reserved_words = ['admin', 'support', 'help', 'root', 'api', 'login', 'signup', 'settings', 'dashboard', 'system', 'staff', 'mod', 'owner', 'blog', 'about', 'contact', 'null', 'undefined']
            if username in reserved_words:
                return jsonify({"success": False, "message": "This username is reserved and cannot be used."})
                
            with db.cursor() as cursor:
                cursor.execute("SELECT user_id FROM users WHERE username = %s", (username,))
                if cursor.fetchone():
                    return jsonify({"success": False, "message": "This username is already taken. Please choose another."})
                    
                cursor.execute("UPDATE users SET username = %s WHERE user_id = %s", (username, user_id))
                
            if is_setup_flow:
                session.pop('setup_user_id', None)
                return jsonify({"success": True, "message": "Username saved! Redirecting to login...", "redirect": url_for('auth.login')})
            else:
                return jsonify({"success": True, "message": "Username saved!"})
                
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error occurred: {str(e)}"}), 500
@auth_bp.route('/set_username', methods=['GET'])
def set_username():
    return render_template('auth/set_username.html')


