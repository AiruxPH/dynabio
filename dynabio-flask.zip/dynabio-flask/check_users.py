import pymysql
try:
    c = pymysql.connect(host='localhost', user='root', password='', database='dynabio', cursorclass=pymysql.cursors.DictCursor)
    cur = c.cursor()
    cur.execute("SELECT user_id, email, username FROM users")
    print(cur.fetchall())
except Exception as e:
    print(e)
